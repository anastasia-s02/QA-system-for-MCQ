with open('out.txt','w') as file:
    file.write('hello world')
    file.close()

